DITTOMON2.0.3 - PUBLIC BETA / OCTOBER 20, 2026
Created and directed by Illy / Illiterally

Download: https://github.com/Illiterally/Dittomon-Mewtation-Beta/releases/download/v2.0.3/Dittomon2.0.3-2026-10-20.zip
Release: https://github.com/Illiterally/Dittomon-Mewtation-Beta/releases/tag/v2.0.3

PATCHING
1. Extract this ZIP.
2. Apply Dittomon2.0.3.bps to your own clean Pokemon FireRed USA 1.0 ROM
   using a BPS patcher. Save the result as Dittomon2.0.3.gba.
   Do not apply the patch to a previous Dittomon ROM.
3. Open the patched ROM in your emulator.

SAVES
Expanded Dittomon2.0 battery saves remain compatible. Back up your original
save first. In mGBA, use a COPY named Dittomon2.0.3.sav beside the new ROM.
In Delta, import a COPY of your ordinary game save into the updated game.
Restart and use Continue. Do not restore an old emulator save state.
Saves from the original Gen 1-3 beta require a fresh game.

FEEDBACK
Please test Route 11 trainers and the Silph elevator first. Record the ROM
filename, emulator/version, location and exact action for any problem.

This ZIP contains a patch, instructions and credits. It contains no ROM,
emulator, or player save. PATCH_INFO.json records the exact file hashes.
