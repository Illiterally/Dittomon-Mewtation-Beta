Dittomon: September 4, 2026 Beta - Warp Hotfix
Prepared October 5, 2026

This repairs the blocked Rocket Hideout B3F stairs and two related warp
errors at Pokemon Tower 7F and Six Island's Outcast Island.
Only three map-data bytes change. All game code and the save format remain
identical to the September 4 beta. No restart or save conversion is needed.

PATCH YOUR EXISTING GAME

The enclosed Apply-to-Dittomon-2026-09-04.bps patch takes the already-patched
September 4 Dittomon beta ROM as input. Do NOT apply it to clean FireRed or
the expanded-roster rebuild. Keep your original ROM as a backup.

1. Open a BPS patcher, such as Floating IPS or Rom Patcher JS.
2. Select your existing September 4 Dittomon .gba as the input ROM.
3. Select Apply-to-Dittomon-2026-09-04.bps as the patch.
4. Save the result with a new filename, such as Dittomon-WarpHotfix.gba.
5. If the patcher reports a source-checksum mismatch, stop: that input is
   a different build. Do not disable checksum verification.

KEEP YOUR PROGRESS IN DELTA

1. Open the OLD game and save using the Pokemon game's own SAVE menu.
   If your latest progress is in a Delta save state, load it in the OLD
   game first, then create that normal in-game save.
2. Return to Delta's library. Long-press the OLD game and choose
   Manage Save File > Export Save File. Keep this backup in Files.
3. Import the corrected .gba using the + button in Delta's library.
4. Long-press the corrected game and choose
   Manage Save File > Import Save File. Select the file from step 2.
5. Boot the corrected game from its title screen and choose CONTINUE.
   Do not restore an old emulator save state into the corrected game.
6. Confirm your trainer/progress and try the stairs. Keep the old game
   and exported save until you have confirmed everything is present.

These menu names follow Delta's official documentation:
https://faq.deltaemulator.com/using-delta/nintendo-ds/incompatible-save-states
(The Export/Import Save File menu is documented there; its DS-specific
Legacy/core migration procedure is NOT needed for this GBA hotfix.)
https://faq.deltaemulator.com/getting-started/importing-games
https://faq.deltaemulator.com/using-delta/save-states

VERIFICATION

The source ROM matches the September 4 public release checksum. The fixed
ROM differs in exactly three bytes; all 1,294 map warp entries match the
clean FireRed base. Applying this BPS reproduces the verified fixed ROM.
Manual emulator traversal and the tester's actual save remain to be checked.

This package contains only a patch and documentation, not a ROM or save.
